#ifndef TRANSFORM_H_INCLUDED
#define TRANSFORM_H_INCLUDED

void myTranslate(GLfloat x,GLfloat y,GLfloat z);
void myRotate(GLfloat degree,GLfloat x,GLfloat y,GLfloat z);


#endif // TRANSFORM_H_INCLUDED
