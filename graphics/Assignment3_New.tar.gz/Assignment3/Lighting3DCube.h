
#include <GL/glut.h>

#ifndef LIGHTING3DCUBE_H_INCLUDED
#define LIGHTING3DCUBE_H_INCLUDED

void CubeInit(GLfloat x,GLfloat y,GLfloat z);
void display(void);

#endif // LIGHTING3DCUBE_H_INCLUDED
