#ifndef SQUAREGO_H_INCLUDED
#define SQUAREGO_H_INCLUDED

void keyboard(unsigned char key, int x, int y);
void reshape (int w, int h);
void display(void);
void SquareInit(void);
void MyShadingDisplay();

#endif // SQUAREGO_H_INCLUDED
