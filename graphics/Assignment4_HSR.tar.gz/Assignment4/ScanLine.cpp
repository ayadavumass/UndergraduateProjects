#include "ScanLine.h"
#include<algorithm>
#include<iostream>

//function declarations
void MakeActiveEdgeList(int ScanLine);
using namespace std;


//function declarations
bool cmpFunc (Info Obj1,Info Obj2) { return (Obj1.IntersectionX<Obj2.IntersectionX); }
bool cmpFunc_Depth (On_Off Obj1,On_Off Obj2) { return (Obj1.Depth<Obj2.Depth); }
void On_Off_Surface(vector<On_Off> *OnFlagCount,int SurfaceNum,int ObjNum);     //now works only for convex
void DepthCalcRoutine(vector<On_Off> *OnFlagCount,int PixX,int PixY);

void PrintEdgeList();

void ScanLineAlgo()
{
    int i=0,j=0,k=0;;
    for(j=0;j<winHeight;j++)   //each scan line
    {
        k=0;
        ActiveEdgeList.clear();
        MakeActiveEdgeList(j);
        if(j==200)
        {
            PrintEdgeList();
        }

        vector<On_Off> OnFlagCount;   // index of surface which is on
        OnFlagCount.clear();
        for(i=0;i<winWidth;i++)
        {
            if(k<ActiveEdgeList.size())
            {
                if(i==(int)ActiveEdgeList.at(k).IntersectionX)
                {
                    while(i==(int)ActiveEdgeList.at(k).IntersectionX)    //pathological case, when two edges have same intersection at scan line
                    {
                    vector<int>::iterator it1;
                    for ( it1=ActiveEdgeList.at(k).SurfaceVect.begin() ; it1 < ActiveEdgeList.at(k).SurfaceVect.end(); it1++ )
                    {
                       // OnFlagCount.push_back(*it1);
                        //SurfaceTable.at(*it1).flag=true;    //turning on the surface
                       On_Off_Surface(&OnFlagCount,(*it1),ActiveEdgeList.at(k).ObjNum);     //now works only for convex
                    }
                    DepthCalcRoutine(&OnFlagCount,i,j);
                    k++;
                    if(k>=ActiveEdgeList.size())
                        break;
                    }
                }
                else if(i<(int)ActiveEdgeList.at(k).IntersectionX)     // intermidiate between intersections
                {
                    DepthCalcRoutine(&OnFlagCount,i,j);
                }
            }
        }
    }
}


void MakeActiveEdgeList(int ScanLine)
{
    vector<Info>::iterator it;
    int i=0;
    for(i=0;i<NUMOBJECTS;i++)
    {
        for ( it=EdgeTable[i].begin() ; it < EdgeTable[i].end(); it++ )
        {
            GLdouble Y1,Y2,X1,X2;

            Y1=VertexTable[i].at((*it).InfoVect.at(0)).y;   // taking y coordinate of both edge points
            Y2=VertexTable[i].at((*it).InfoVect.at(1)).y;

            X1=VertexTable[i].at((*it).InfoVect.at(0)).x;   // taking x coordinate of both edge points
            X2=VertexTable[i].at((*it).InfoVect.at(1)).x;

            if(((Y1-ScanLine)*(Y2-ScanLine))<0)   // edge intersects scanline
            {
                GLdouble Scn=ScanLine;
                //GLdouble IntersectionX=(((Scn-Y1)*(X1-X2))/(Y1-Y2))+ X1;   //intersection X on scanline
                GLdouble IntersectionX=((Scn-Y1)*(*it).InverseSlope)+X1;
                (*it).IntersectionX=IntersectionX;
                ActiveEdgeList.push_back((*it));
            }else{

            }
        }
    }
    if(ActiveEdgeList.size()>0)
        sort (ActiveEdgeList.begin(), ActiveEdgeList.end(), cmpFunc);
}

void DepthCalcRoutine(vector<On_Off> *OnFlagCount,int PixX,int PixY)
{
    GLdouble A,B,C,D;
    if(OnFlagCount->size()>0)
    {
        vector<On_Off>::iterator it;
        for ( it=OnFlagCount->begin() ; it < OnFlagCount->end(); it++ ) // every edge of surface
        {
            A=SurfaceTable[(*it).ObjNum].at((*it).SurfNum).A;
            B=SurfaceTable[(*it).ObjNum].at((*it).SurfNum).B;
            C=SurfaceTable[(*it).ObjNum].at((*it).SurfNum).C;
            D=SurfaceTable[(*it).ObjNum].at((*it).SurfNum).D;
            (*it).Depth=(-A*PixX-B*PixY-D)/C;
        }
         sort (OnFlagCount->begin(), OnFlagCount->end(), cmpFunc_Depth);
         if(OnFlagCount->at(0).ObjNum==0)
         {
             FB[PixY][PixX][0]=1.0;
             FB[PixY][PixX][1]=0.0;
             FB[PixY][PixX][2]=0.0;

         }else if(OnFlagCount->at(0).ObjNum==1)
         {
             FB[PixY][PixX][0]=0.0;
             FB[PixY][PixX][1]=1.0;
             FB[PixY][PixX][2]=0.0;

         }

    }

}

void On_Off_Surface(vector<On_Off> *OnFlagCount,int SurfaceNum,int ObjNum)     //now works only for convex
{
    vector<On_Off>::iterator it;
    bool found=false;
    for ( it=OnFlagCount->begin() ; it < OnFlagCount->end(); it++ ) // every edge of surface
    {
        if(((*it).SurfNum==SurfaceNum) && ((*it).ObjNum==ObjNum))
        {
            found=true;
            break;
        }
    }
    if(found)   //right edge has come, off the surface
    {
        OnFlagCount->erase(it);
        SurfaceTable[ObjNum].at(SurfaceNum).flag=false;    //turning on the surface
    }else{    //left edge is there on the surface
        On_Off Obj;
        Obj.SurfNum=SurfaceNum;
        Obj.ObjNum=ObjNum;
        OnFlagCount->push_back(Obj);
        SurfaceTable[ObjNum].at(SurfaceNum).flag=true;    //turning on the surface
        }
}

void PrintEdgeList()
{
    cout<<"Printing Active Edge List"<<endl;
    vector<Info>::iterator it1;
    for ( it1=ActiveEdgeList.begin() ; it1 < ActiveEdgeList.end(); it1++ )
        {
            cout<<"ObjNum "<<(*it1).ObjNum<<"Num "<<(*it1).Num<<"IntersectionX "<<(*it1).IntersectionX<<endl;

        }
}
