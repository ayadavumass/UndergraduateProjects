#ifndef PERSSCENE_H_INCLUDED
#define PERSSCENE_H_INCLUDED

void PersSceneInit();
 void resize(int width, int height);
 void display(void);
 void key(unsigned char key, int x, int y);


#endif // PERSSCENE_H_INCLUDED
