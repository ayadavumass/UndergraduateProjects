#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <vector>
#ifndef SCANLINE_H_INCLUDED
#define SCANLINE_H_INCLUDED
#define NUMOBJECTS  2
typedef struct Info{
    int Num;
    std::vector<int> InfoVect;
    std::vector<int> SurfaceVect;
    bool flag;         //on off for surface  used only in SurfaceTable
    int ObjNum;         // for finding which object this edge belongs during active edge list formation
}Info;
typedef struct Point{
    int Num;
    GLdouble x;
    GLdouble y;
    GLdouble z;
}Point;

extern std::vector<Point> VertexTable[NUMOBJECTS];
extern std::vector<Info> EdgeTable[NUMOBJECTS];
extern std::vector<Info> SurfaceTable[NUMOBJECTS];
extern const int winWidth,winHeight;

#endif // SCANLINE_H_INCLUDED
