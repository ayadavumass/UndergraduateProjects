#include "frame.h"

/*Used for hashing*/
