int main()
{
	int a,b,c,d;
	char ch;
	a=b+6;
	if(a>=b)
	{
		c=10;
		ch='a';
	}else
	{
		d=10;
		ch='b';
	}
	return 0;
}
