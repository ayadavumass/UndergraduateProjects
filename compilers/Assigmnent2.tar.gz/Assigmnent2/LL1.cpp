#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<sstream>
#include<map>
using namespace std;

typedef struct GrammerRules{
    string Left;
    vector<string> Right;
    vector<string> First;
    vector<string> Follow;
    bool FirstCalc;
    bool FollowCalc;
    bool Start;
}GrammerRules;

typedef struct PTEntry{
    string Left;
    string Right;
}PTEntry;

typedef struct ParsingTableKey{
    string Row;
    string Col;
}ParsingTableKey;


struct cmp_Func
	{
	   bool operator()(ParsingTableKey  O1, ParsingTableKey  O2)
	   {
	       if(O1.Row<O2.Row)
	       return true;
	       else if(O1.Row==O2.Row){
	           if(O1.Col<O2.Col)
	           return true;
	       }
	       else return false;
	      //return std::strcmp(a, b) < 0;
	   }
	};
//Global variables
vector<GrammerRules> RulesObj;
bool FindStart=false;
map<ParsingTableKey,PTEntry,cmp_Func> ParsingTable;
//vector<ParsingTable> LLTable;

//function decarations
void EnterGrammer(string line);
void CalculateFirst(GrammerRules *Obj);
void StringFirst(string str,bool *epsilon,vector<string> *First);
void EnterFollow(vector<string> * Follow,vector<string> First);
void CalculateFollow(GrammerRules *Obj);
void MakeTable();




int main()
{
    string line;




    ifstream Grammerfile("Grammar.txt");
    if (Grammerfile.is_open())
    {
        while ( Grammerfile.good() )
        {
            getline (Grammerfile,line);
            EnterGrammer(line);
            cout << line << endl;
        }
        Grammerfile.close();
    }
else cout << "Unable to open Grammer File";


//calculating FIRST
       vector<GrammerRules>::iterator it;    //finding whether this non terminal has first calculated or not
                               for ( it=RulesObj.begin() ; it < RulesObj.end(); it++ )
                                {
                                    if(!(*it).FirstCalc)
                                    {
                                        CalculateFirst(&(*it));
                                    }

                                }

                                cout<<"FIRST PRINTING"<<endl;
//       vector<GrammerRules>::iterator it;    //finding whether this non terminal has first calculated or not
                               for ( it=RulesObj.begin() ; it < RulesObj.end(); it++ )
                                {
                                  cout<<(*it).Left<<" "<<(*it).FirstCalc<<" ";
                                  vector<string>::iterator it2;
                                  for ( it2=(*it).First.begin() ; it2 < (*it).First.end(); it2++ )
                                    {
                                        cout<<(*it2)<<" ";
                                    }
                                    cout<<endl;
                                }


                                //calculating FOLLOW

                                for ( it=RulesObj.begin() ; it < RulesObj.end(); it++ )
                                {
                                    if((*it).Start)
                                    {
                                        (*it).Follow.push_back("$");    //applying 1st rule of follow
                                    }
                                    if(!(*it).FollowCalc)
                                    {
                                        CalculateFollow(&(*it));
                                    }

                                }





                                cout<<"FOLLOW PRINTING"<<endl;
//       vector<GrammerRules>::iterator it;    //finding whether this non terminal has first calculated or not
                               for ( it=RulesObj.begin() ; it < RulesObj.end(); it++ )
                                {
                                  cout<<(*it).Left<<" "<<(*it).FollowCalc<<" ";
                                  vector<string>::iterator it2;
                                  for ( it2=(*it).Follow.begin() ; it2 < (*it).Follow.end(); it2++ )
                                    {
                                        cout<<(*it2)<<" ";
                                    }
                                    cout<<endl;
                                }

                                MakeTable();


                                cout<<"PRINTING LL1 TABLE"<<endl;

                                for( map<ParsingTableKey,PTEntry,cmp_Func>::iterator ii=ParsingTable.begin(); ii!=ParsingTable.end(); ++ii)
                                {
                                    cout << (*ii).first.Row <<" , "<<(*ii).first.Col<< " : " << (*ii).second.Left <<"-->"<<(*ii).second.Right<< endl;
                                }


    return 0;
}

void EnterGrammer(string line)
{
    istringstream iss(line);
    string str[3];         // for left side, right side of grammer rule
    int i=0;
            do
            {
                //string sub;
                iss >> str[i];

                    cout << "Substring: " << i <<" "<< str[i] << endl;
                    i++;
            } while (iss);

            vector<GrammerRules>::iterator it;
            bool found =false;

            if(!str[0].compare(""))
            {
                cout<<"here";
            return;
            }

                for ( it=RulesObj.begin() ; it < RulesObj.end(); it++ )
                    {
                        if(!(*it).Left.compare(str[0]))
                        {
                            found=true;
                            (*it).Right.push_back(str[1]);

                        }
                    }
                    if(!found)
                    {
                        GrammerRules Obj;
                        Obj.Left.assign(str[0]);
                        Obj.Right.push_back(str[1]);
                        Obj.FirstCalc=false;
                        Obj.FollowCalc=false;
                        Obj.First.clear();
                        Obj.Follow.clear();

                        if(!FindStart)   //here assuming first line in Grammar.txt file is start symbol
                        {
                            Obj.Start=true;
                            FindStart=true;
                        }
                        RulesObj.push_back(Obj);
                    }
}


void CalculateFirst(GrammerRules *Obj)
{
    vector<string>::iterator it;
    for ( it=Obj->Right.begin() ; it < Obj->Right.end(); it++ )    //considering rules one by one
                    {
                        string str;
                        str.assign((*it));
                        int i=0;
                        bool epsilon=false;
                        StringFirst(str,&epsilon,&(Obj->First));
                     /*   for(i=0;i<str.length();i++)
                        {

                        char ch=str.at(i);
                        if(ch>=65&&ch<=90)  // capital is first letter, so Non Terminal is in front
                        {

                            vector<GrammerRules>::iterator it1;    //finding whether this non terminal has first calculated or not
                               for ( it1=RulesObj.begin() ; it1 < RulesObj.end(); it1++ )
                                {
                                    if((*it1).Left.at(0)==ch)
                                    {
                                        if(!(*it1).FirstCalc){   //calculate by recursion
                                            CalculateFirst(&(*it1));
                                        }
                                        break;
                                    }
                                }

                                        vector<string>::iterator it2;
                                        bool localepsilon=false;

                                        for ( it2=(*it1).First.begin() ; it2 < (*it1).First.end(); it2++ )    // A->N1B putting everything in FIRST(N1) into FIRST(A),
                                        {
                                            if(!(*it2).compare("~"))
                                            {

                                                localepsilon=true;

                                            }else{
                                                Obj->First.push_back(*it2);
                                            }
                                        }

                                        if(localepsilon)
                                        {
                                            epsilon=true;
                                        }else{
                                            epsilon=false;
                                            break;
                                        }

                                }else{
                            if(ch=='~') //some special identifier or epsilon is there, special identitiefer s liek id are denoted by ~i
                            {
                                if(str.length()==1)   //case of epsilon(~)
                                {
                                    //Obj->First.push_back(str);
                                    epsilon=true;
                                    break;

                                }else if(str.length()>1){
                                    i++;
                                    char chs=str.at(i);
                                    string sid;
                                    sid.push_back(ch);
                                    sid.push_back(chs);
                                    Obj->First.push_back(sid);
                                    epsilon=false;
                                    break;
                                }

                            }else{   //simple terminal is there
                                string chs;
                                chs.push_back(ch);
                                Obj->First.push_back(chs);
                                epsilon=false;
                                break;
                                }
                        }
                    }*/

                    if(epsilon)
                    {
                       Obj->First.push_back("~");
                    }

                }
                     Obj->FirstCalc=true;
    }

void CalculateFollow(GrammerRules *Obj)
{
  //  cout<<"Follow Cal"<<endl;
    vector<GrammerRules>::iterator it1;
    for ( it1=RulesObj.begin() ; it1 < RulesObj.end(); it1++ )   //searching for all non terminals
            {
                 vector<string>::iterator it2;
                 for ( it2=(*it1).Right.begin() ; it2 < (*it1).Right.end(); it2++ )    // searhig for all rules in all non terminals
                    {
                        int i=0,pos=0,found=0;
                        //for(i=0;i<(*it2).length();i++)
                        while(pos<(*it2).length())
                        {
                            found=(*it2).find(Obj->Left.c_str(),pos,1);
                            if (found!=string::npos)   //condition for found
                            {
                                pos=found+1;
                                if(pos<(*it2).length())      // checking for case A->(alpha)B(Beta)
                                {
                                string str=(*it2).substr(pos);
                                bool epsilon=false;
                                vector<string> First;
                                StringFirst(str,&epsilon,&First);

                                EnterFollow(&(Obj->Follow),First);


                                if(epsilon)   //case A->(alpha)B(Beta) FIRST((Beta)) contains epsilon
                                {
                                    if((*it1).Left.compare(Obj->Left))         //skipping rules of the form A->(alpha)A(beta)
                                    {
                                    if(!(*it1).FollowCalc)   //Follow not calculated
                                    {

                                        CalculateFollow(&(*it1));
                                    }
                                    EnterFollow(&(Obj->Follow),(*it1).Follow);
                                    }

                                }
                            }else{    //found on the last     case A->(alpha)B

                                 if((*it1).Left.compare(Obj->Left))    //skipping rules of the form A->(alpha)A
                                 {
                                 if(!(*it1).FollowCalc)   //Follow not calculated
                                    {
                                        CalculateFollow(&(*it1));
                                    }
                                    EnterFollow(&(Obj->Follow),(*it1).Follow);
                                 }


                                }
                                //char ch=(*it2).at(pos);

                            }else{
                                break;
                            }
                        }
                    }
                }
                Obj->FollowCalc=true;
}

void StringFirst(string str,bool *epsilon,vector<string> *First)
{
    //vector<string> First;
    int i=0;
    for(i=0;i<str.length();i++)
                        {

                        char ch=str.at(i);
                        if(ch>=65&&ch<=90)  // capital is first letter, so Non Terminal is in front
                        {

                            vector<GrammerRules>::iterator it1;    //finding whether this non terminal has first calculated or not
                               for ( it1=RulesObj.begin() ; it1 < RulesObj.end(); it1++ )
                                {
                                    if((*it1).Left.at(0)==ch)
                                    {
                                        if(!(*it1).FirstCalc){   //calculate by recursion
                                            CalculateFirst(&(*it1));
                                        }
                                        break;
                                    }
                                }

                                        vector<string>::iterator it2;
                                        bool localepsilon=false;

                                        for ( it2=(*it1).First.begin() ; it2 < (*it1).First.end(); it2++ )    // A->N1B putting everything in FIRST(N1) into FIRST(A),
                                        {
                                            if(!(*it2).compare("~"))
                                            {

                                                localepsilon=true;

                                            }else{
                                               // Obj->First.push_back(*it2);
                                               First->push_back(*it2);
                                            }
                                        }

                                        if(localepsilon)
                                        {
                                            *epsilon=true;
                                        }else{
                                            *epsilon=false;
                                            break;
                                        }

                                }else{
                            if(ch=='~') //some special identifier or epsilon is there, special identitiefer s liek id are denoted by ~i
                            {
                                if(str.length()==1)   //case of epsilon(~)
                                {
                                    //Obj->First.push_back(str);
                                    *epsilon=true;
                                    break;

                                }else if(str.length()>1){
                                    i++;
                                    char chs=str.at(i);
                                    string sid;
                                    sid.push_back(ch);
                                    sid.push_back(chs);
                                    First->push_back(sid);
                                    *epsilon=false;
                                    break;
                                }

                            }else{   //simple terminal is there
                                string chs;
                                chs.push_back(ch);
                                First->push_back(chs);
                                *epsilon=false;
                                break;
                                }
                        }
                    }
}

void EnterFollow(vector<string> * Follow,vector<string> First)
{
    vector<string>::iterator it3;
    for ( it3=First.begin() ; it3 < First.end(); it3++ )
                                {
                                    bool found=false;
                                    vector<string>::iterator it4;
                                    for ( it4=Follow->begin() ; it4 < Follow->end(); it4++ )         // checking for duplicates
                                    {
                                        if(!(*it3).compare(*it4))
                                        {
                                            found=true;
                                            break;
                                        }
                                    }
                                    if(!found)
                                    {
                                        (*Follow).push_back(*it3);
                                    }
                                }
}


void MakeTable()
{
      vector<GrammerRules>::iterator it1;
    for ( it1=RulesObj.begin() ; it1 < RulesObj.end(); it1++ )
            {
                vector<string>::iterator it2;
                for ( it2=(*it1).Right.begin() ; it2 < (*it1).Right.end(); it2++ )
                {
                    bool epsilon=false;
                    vector<string>  Vect;
                    StringFirst((*it2),&epsilon,&Vect);
                    vector<string>::iterator it3;


                    for ( it3=Vect.begin() ; it3 < Vect.end(); it3++ )    //applying Rules 1 Of book
                    {
                        pair<map<ParsingTableKey,PTEntry,cmp_Func>::iterator,bool> ret;

                        ParsingTableKey Key;
                        PTEntry Entry;
                        Key.Row.assign((*it1).Left);
                        Key.Col.assign(*it3);

                        Entry.Left.assign((*it1).Left);
                        Entry.Right.assign(*it2);

                        ret=ParsingTable.insert(pair<ParsingTableKey,PTEntry>(Key,Entry));
                        if(!ret.second)
                        {
                            cout<<"Duplicate Entry"<<endl;
                        }
                    }

                    if(epsilon)          //appying Rule 2
                    {
                         for ( it3=(*it1).Follow.begin() ; it3 < (*it1).Follow.end(); it3++ )
                        {
                        pair<map<ParsingTableKey,PTEntry,cmp_Func>::iterator,bool> ret;

                        ParsingTableKey Key;
                        PTEntry Entry;
                        Key.Row.assign((*it1).Left);
                        Key.Col.assign(*it3);

                        Entry.Left.assign((*it1).Left);
                        Entry.Right.assign(*it2);

                        ret=ParsingTable.insert(pair<ParsingTableKey,PTEntry>(Key,Entry));
                            if(!ret.second)
                            {
                                cout<<"Duplicate Entry"<<endl;
                            }
                        }

                    }
                }
            }
}
